<template>
    <div class="weather-card">
      <img v-lazy="cityImage" alt="City image" class="image" />
      <div class="content">
        <div class="title">{{ city }}</div>
        <p>Temperature: {{ currentTemp }} °C</p>
        <p>Rain: {{ rain }} mm</p>
        <p>Wind: {{ windSpeed }} m/s</p>
        <p>Cloud Cover: {{ cloudCover }} %</p>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'WeatherCard',
    props: {
      city: {
        type: String,
        required: true
      }
    },
    data() {
      return {
        weatherData: null,
        timer: null // Initialize timer to null
      };
    },
    created() {
      this.fetchWeatherData();
      this.timer = setInterval(this.fetchWeatherData, 60000); // Update every minute
    },
    beforeUnmount() {
      clearInterval(this.timer); // Clear timer on component unmount
    },
    methods: {
      async fetchWeatherData() {
        try {
          const url = `http://localhost:1234/api/weather/${this.city.toLowerCase()}`;
          const response = await fetch(url);
          this.weatherData = await response.json();
        } catch (error) {
          console.error('Error fetching weather data:', error);
        }
      },
    },
    computed: {
      currentTemp() {
        return this.weatherData?.temperature_2m;
      },
      rain() {
        return this.weatherData?.rain;
      },
      windSpeed() {
        return this.weatherData?.wind_speed_10m;
      },
      cloudCover() {
        return this.weatherData?.cloud_cover;
      },
      cityImage() {
        return `https://source.unsplash.com/featured/?${this.city}`;
      },
    },
  };
  </script>
  
  <style scoped>
  .weather-card {
    max-width: 350px;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    margin: 20px auto;
  }
  
  .image {
    width: 100%;
    height: 200px;
    background-size: cover;
    background-position: center;
  }
  
  .content {
    padding: 20px;
    background: #fff;
  }
  
  .title {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 10px;
  }
  
  p {
    margin: 5px 0;
    color: #333;
  }
  </style>
  