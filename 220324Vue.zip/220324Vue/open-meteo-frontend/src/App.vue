<template>
  <div class="container">
    <h1 class="text-4xl font-bold mb-8">Aktuální počasí v českých městech</h1>
    <div class="card-container">
      <Prague ref="Praha" city="Prague" @update="updateWeather" />
      <Brno ref="brno" city="Brno" @update="updateWeather" />
      <Ostrava ref="ostrava" city="Ostrava" @update="updateWeather" />
    </div>
    <p class="mt-8 text-gray-600">Poslední aktualizace: {{ lastUpdated }}</p>
    <button class="btn mt-6" @click="updateWeather">Aktualizovat</button>
  </div>
</template>

<script>
import Prague from './components/Prague.vue';
import Brno from './components/Brno.vue';
import Ostrava from './components/Ostrava.vue';

export default {
  components: {
    Prague,
    Brno,
    Ostrava,
  },
  data() {
    return {
      lastUpdated: null,
    };
  },
  mounted() {
    this.updateWeather();
  },
  methods: {
    updateWeather() {
      this.lastUpdated = new Date();
    },
  },
};
</script>

<style scoped>
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.card-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 20px;
}

.card-container > * {
  padding: 20px;
  border-radius: 20px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  background-color: #fff;
  transition: transform 0.3s ease-in-out;
}

.card-container > *:hover {
  transform: translateY(-5px);
}

h1 {
  text-align: center;
  color: #333;
}

.btn {
  padding: 12px 24px;
  font-size: 1.2em;
  border-radius: 8px;
  border: none;
  background-color: #007BFF;
  color: white;
  cursor: pointer;
  transition: background-color 0.3s;
}

.btn:hover {
  background-color: #0056b3;
}

.btn:focus {
  outline: none;
  box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.3);
}
</style>
