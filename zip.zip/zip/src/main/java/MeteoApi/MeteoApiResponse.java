package MeteoApi;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MeteoApiResponse {

    private double latitude;
    private double longitude;
    private double generationtime_ms;
    private int utc_offset_seconds;
    private String timezone;
    private String timezone_abbreviation;
    private double elevation;

    @JsonProperty("current_units")
    private CurrentUnits currentUnits;

    @JsonProperty("current")
    private Current current;


    @Getter
    @Setter
    public static class CurrentUnits {
        private String time;
        private String interval;
        private String temperature_2m;
        private String precipitation;
        private String rain;
        private String snowfall;
        private String weather_code;
        private String cloud_cover;
        private String wind_speed_10m;

    }

    @Getter
    @Setter
    public static class Current {
        private String time;
        private int interval;
        private double temperature_2m;
        private double precipitation;
        private double rain;
        private double snowfall;
        private int weather_code;
        private int cloud_cover;
        private double wind_speed_10m;

    }
}