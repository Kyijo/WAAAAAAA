package MeteoApi;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;

@RestController
public class ApiController {

    @GetMapping("/api/weather/prague")
    @CrossOrigin
    public ResponseEntity<WeatherData> fetchPragueData() {
        RestTemplate restTemplate = new RestTemplate();
        String url = "https://api.open-meteo.com/v1/forecast?latitude=50.088&longitude=14.4208&current=temperature_2m,precipitation,rain,snowfall,weather_code,cloud_cover,wind_speed_10m";
        MeteoApiResponse response = restTemplate.getForObject(url, MeteoApiResponse.class);

        if (response != null) {
            WeatherData weatherData = getWeatherData(response);

            return new ResponseEntity<>(weatherData, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/api/weather/brno")
    @CrossOrigin
    public ResponseEntity<WeatherData> fetchBrnoData() {
        RestTemplate restTemplate = new RestTemplate();
        String url = "https://api.open-meteo.com/v1/forecast?latitude=49.8233&longitude=13.6654&current=temperature_2m,precipitation,rain,snowfall,weather_code,cloud_cover,wind_speed_10m";
        MeteoApiResponse response = restTemplate.getForObject(url, MeteoApiResponse.class);

        if (response != null) {
            WeatherData weatherData = getWeatherData(response);

            return new ResponseEntity<>(weatherData, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/api/weather/ostrava")
    @CrossOrigin
    public ResponseEntity<WeatherData> fetchOstravaData() {
        RestTemplate restTemplate = new RestTemplate();
        String url = "https://api.open-meteo.com/v1/forecast?latitude=49.8347&longitude=18.282&current=temperature_2m,precipitation,rain,snowfall,weather_code,cloud_cover,wind_speed_10m";
        MeteoApiResponse response = restTemplate.getForObject(url, MeteoApiResponse.class);

        if (response != null) {
            WeatherData weatherData = getWeatherData(response);

            return new ResponseEntity<>(weatherData, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    private WeatherData getWeatherData(MeteoApiResponse response) {
        WeatherData weatherData = new WeatherData();
        weatherData.setTimezone(response.getTimezone());
        weatherData.setElevation(response.getElevation());
        weatherData.setTime(LocalDateTime.parse(response.getCurrent().getTime()));
        weatherData.setTemperature_2m(response.getCurrent().getTemperature_2m());
        weatherData.setRain(response.getCurrent().getRain());
        weatherData.setSnowfall(response.getCurrent().getSnowfall());
        weatherData.setWind_speed_10m(response.getCurrent().getWind_speed_10m());
        weatherData.setCloud_cover(response.getCurrent().getCloud_cover());
        weatherData.setWeather_code(response.getCurrent().getWeather_code());
        return weatherData;
    }
}