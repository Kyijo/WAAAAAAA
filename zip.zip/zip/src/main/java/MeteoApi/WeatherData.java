package MeteoApi;

import lombok.*;

import java.time.LocalDateTime;

@AllArgsConstructor
@Builder
@NoArgsConstructor
@Data
@Getter
@Setter
public class WeatherData {

    private String timezone;
    private double elevation;
    private LocalDateTime time;
    private double temperature_2m;
    private double rain;
    private double snowfall;
    private double wind_speed_10m;
    private int cloud_cover;
    private int weather_code;
}
